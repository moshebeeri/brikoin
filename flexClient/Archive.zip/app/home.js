import React from 'react'
import PropTypes from 'prop-types'
import VideoComponent from './VideoComponent';
import RaisedButton from 'material-ui/RaisedButton';
class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {role:''}
    }

    componentDidUpdate () {

    }

    selectRole(role){
        this.setState({
            role: role
        })
    }

    render () {
        return <div>
            {!this.state.role && <RaisedButton label="Banker" secondary={true} onClick={this.selectRole.bind(this,'banker')} />}
            {!this.state.role && <RaisedButton label="Customer" secondary={true} onClick={this.selectRole.bind(this, 'Customer')} />}

            {this.state.role  && <VideoComponent role={this.state.role}/> }

        </div>
    }
}

Home.contextTypes = {
    drizzle: PropTypes.object
}

export default Home
